You can find the original project on this directory :
	/PMP/SCHEME UML/MyQCMProjectScheme.mdj

The original project can be open with STARUML software
	/PMP/TOOLS/STARUML