You can find the original project on this directory :
	/PMP/base de données/Server/MyQCM_DiagramClassServer.zargo

The original project can be open with ArgoUML software
	/PMP/TOOLS/ARGOUML