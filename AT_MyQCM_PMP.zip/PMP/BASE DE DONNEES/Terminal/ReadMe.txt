You can find the original project on this repertory :
	/PMP/SCHEME/MyQCMProjectScheme.mdj
This project can be open by StarUML software. You can find the launcher in this repertory :
	/PMP/Tool/StarUML/